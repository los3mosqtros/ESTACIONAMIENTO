<?php
include('conexion.php');
include("barra_lateral.php");
date_default_timezone_set('America/Mexico_City');
?>
<html>
<title>Document</title>

<body>
	<div class="ContenedorPrincipal">
		<?php

		$filasmax = 7;

		if (isset($_POST['btnbuscar'])) {
			$buscar = $_POST['txtbuscar'];
			$sqlcat = mysqli_query($conn, "SELECT * FROM parking WHERE nombre LIKE '" . $buscar . "'");
		} else {
			$sqlcat = mysqli_query($conn, "SELECT * FROM parking ORDER BY id DESC LIMIT " . (($pagina - 1) * $filasmax)  . "," . $filasmax);
		}

		$resultadoMaximo = mysqli_query($conn, "SELECT count(*) as num_parking FROM parking");

		$maxusutabla = mysqli_fetch_assoc($resultadoMaximo)['num_parking'];

		?>
		<div class="ContenedorTabla">
			<h1>Estacionamiento</h1>
			<table>
				<tr>
					<th>Id</th>
					<th>Nombre del dueño</th>
					<th>Tipo de vehiculo</th>
					<th>Placas</th>
					<th>Modelo</th>
					<th>Hora de entrada</th>
					<th>Hora de salida</th>
					<th>Costo</th>
					<th>Acción</th>

				</tr>
				<?php while ($fila = mysqli_fetch_assoc($sqlcat)) :
					$precio = 0;
					switch ($fila['tipo']) {
						case 'moto':
							$precio = 10;
							break;
						case 'carro':
							$precio = 15;
							break;
						case 'camioneta':
							$precio = 20;
							break;
						case 'camion':
							$precio = 25;
							break;
					}
				?>

					<tr>
						<td><?php echo $fila['id'] ?></td>
						<td><?php echo $fila['nombre'] ?></td>
						<td><?php echo $fila['tipo'] ?></td>
						<td><?php echo $fila['placas'] ?></td>
						<td><?php echo $fila['modelo'] ?></td>
						<td><?php echo $fila['entrada'] ?></td>
						<td><?php echo $fila['salida'] ?></td>
						<td><?php
							if (empty($fila['costo'])) {
								$creado = new DateTime($fila['entrada']);
								$ahora = new DateTime(date("Y-m-d H:i:s"));

								$intervalo = $ahora->diff($creado);

								$horas = $intervalo->days * 24 + $intervalo->h + $intervalo->i / 60 + $intervalo->s / 3600;

								echo '$' . floor(floor($horas) * $precio);
							} else {
								echo $fila['costo'];
							}
							?></td>
					<?php
					echo "<td style='width:24%'>
				<a class='BotonesTeam1' href=\"./parking/parking_ver.php?id=$fila[id]&pag=$pagina\">&#x1F50D;</a> 
				<a class='BotonesTeam2' href=\"./parking/parking_modificar.php?id=$fila[id]&pag=$pagina\">&#128397;</a>";
				if (empty($fila['costo']))  echo "<a class='BotonesTeam3' href=\"./parking/parking_eliminar.php?id=$fila[id]&pag=$pagina\" onClick=\"return confirm('¿Desea pagar el vhiculo $fila[nombre]?')\">$</a></td>";
					echo "</tr>";
				endwhile;

					?>
			</table>
			<div style='text-align:right'>
				<br>
				<?php echo "Total de veiculos: " . $maxusutabla; ?>
			</div>
		</div>
		<div style='text-align:right'>
			<br>
		</div>
		<div style="text-align:center">
			<?php
			if (isset($_GET['pag'])) {
				if ($_GET['pag'] > 1) {
			?>
					<a class="BotonesTeam4" href="parking_tabla.php?pag=<?php echo $_GET['pag'] - 1; ?>">Anterior</a>
				<?php
				} else {
				?>
					<a class="BotonesTeam4" href="#" style="pointer-events: none">Anterior</a>
				<?php
				}
				?>

			<?php
			} else {
			?>
				<a class="BotonesTeam4" href="#" style="pointer-events: none">Anterior</a>
				<?php
			}

			if (isset($_GET['pag'])) {
				if ((($pagina) * $filasmax) < $maxusutabla) {
				?>
					<a class="BotonesTeam4" href="parking_tabla.php?pag=<?php echo $_GET['pag'] + 1; ?>">Siguiente</a>
				<?php
				} else {
				?>
					<a class="BotonesTeam4" href="#" style="pointer-events: none">Siguiente</a>
				<?php
				}
				?>
			<?php
			} else {
			?>
				<a class="BotonesTeam4" href="parking_tabla.php?pag=2">Siguiente</a>
			<?php
			}
			?>
		</div>
	</div>
</body>

</html>