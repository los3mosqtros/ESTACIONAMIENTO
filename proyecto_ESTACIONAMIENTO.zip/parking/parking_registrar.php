<?php
include('../conexion.php');
include("../parking_tabla.php");
date_default_timezone_set('America/Mexico_City');

$pagina = $_GET['pag'];
?>
<html>

<head>
	<title>Document</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="../css/style.css">
</head>

<body>
	<div class="caja_popup2">
		<form class="contenedor_popup" method="POST">
			<table>
				<tr>
					<th colspan="2">Agregar vehiculo</th>
				</tr>
				<tr>
					<td>Nombre del dueño</td>
					<td><input type="text" name="txtnom" autocomplete="off" class="CajaTexto"></td>
				</tr>
				<tr>
					<td colspan="2">
						<select id="tipo" name="tipo">
							<option value="">Selecciona un vehiculo</option>
							<option value="moto">Moto $10/hora</option>
							<option value="carro">Carro $15/hora</option>
							<option value="camioneta">Camioneta $20/hora</option>
							<option value="camion">Camión $25/hora</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>Placas</td>
					<td><input type="text" name="placas" autocomplete="off" class="CajaTexto" oninput="this.form.placas.value.toUpperCase();"></td>
				</tr>
				<tr>
					<td>Modelo</td>
					<td><input type="text" name="modelo" autocomplete="off" class="CajaTexto"></td>
				</tr>
				<tr>
					<td colspan="2">
						<?php echo "<a class='BotonesTeam' href=\"../parking_tabla.php?pag=$pagina\">Cancelar</a>"; ?>&nbsp;
						<input class='BotonesTeam' type="submit" name="btnregistrar" value="Registrar" onClick="javascript: return confirm('¿Deseas registrar a este veiculo?');">
					</td>
				</tr>
			</table>
		</form>
	</div>
</body>

</html>
<?php

if (isset($_POST['btnregistrar']) && (isset($_POST['tipo']) && $_POST['tipo'] != "")) {
	$nombre 	= $_POST['txtnom'];
	$tipo = $_POST['tipo'];
	$placas = $_POST['placas'];
	$modelo = $_POST['modelo'];

	$ini = date("Y-m-d H:i:s");

	$queryadd	= mysqli_query($conn, "INSERT INTO parking(nombre, tipo, placas, modelo, entrada) VALUES('$nombre', '$tipo', '$placas', '$modelo', '$ini')");

	if (!$queryadd) {
		echo "<script>alert('¡Error!, intenta otra vez');</script>";
	} else {
		echo "<script>window.location='../parking_tabla.php?pag=1' </script>";
	}
}
?>