<?php
include('../conexion.php');
include("../parking_tabla.php");
date_default_timezone_set('America/Mexico_City');

$pagina = $_GET['pag'];
$id = $_GET['id'];

$querybuscar = mysqli_query($conn, "SELECT * FROM parking WHERE id = '$id'");

while ($mostrar = mysqli_fetch_array($querybuscar)) {
    $id    = $mostrar['id'];
    $nombre = $mostrar['nombre'];
    $tipo = $mostrar['tipo'];
    $placas = $mostrar['placas'];
    $modelo = $mostrar['modelo'];
    $entrada = $mostrar['entrada'];
    $salida = date("Y-m-d H:i:s");

    switch ($mostrar['tipo']) {
        case 'moto':
            $precio = 10;
            break;
        case 'carro':
            $precio = 15;
            break;
        case 'camioneta':
            $precio = 20;
            break;
        case 'camion':
            $precio = 25;
            break;
    }

    $creado = new DateTime($mostrar['entrada']);
    $ahora = new DateTime(date("Y-m-d H:i:s"));

    $intervalo = $ahora->diff($creado);

    $horas = $intervalo->days * 24 + $intervalo->h + $intervalo->i / 60 + $intervalo->s / 3600;

    $costo = '$' . floor(floor($horas) * $precio);
}
?>

<html>
<link rel="stylesheet" href="../css/style.css">

<body>
    <div class="caja_popup2">
        <form class="contenedor_popup" method="POST">
            <table>
                <tr>
                    <th colspan="2">Ver datos del vehiculo</th>
                </tr>
                <tr>
                    <td><b>Id:</b></td>
                    <td><?php echo $id ?></td>
                </tr>

                <tr>
                    <td><b>Nombre: </b></td>
                    <td><?php echo $nombre ?></td>
                </tr>

                <tr>
                    <td><b>Tipo de veiculo: </b></td>
                    <td><?php echo $tipo ?></td>
                </tr>

                <tr>
                    <td><b>Placas: </b></td>
                    <td><?php echo $placas ?></td>
                </tr>

                <tr>
                    <td><b>Modelo: </b></td>
                    <td><?php echo $modelo ?></td>
                </tr>

                <tr>
                    <td><b>Entrada: </b></td>
                    <td><?php echo $entrada ?></td>
                </tr>

                <tr>
                    <td><b>Salida: </b></td>
                    <td><?php echo $salida ?></td>
                </tr>

                <tr>
                    <td><b>Costo: </b></td>
                    <td><?php echo $costo ?></td>
                </tr>

                <td colspan="2">
                    <?php echo '<a class="BotonesTeam1" href="../parking_tabla.php?pag=' . $pagina . '">Atras</a>' ?>
                    <input class='BotonesTeam' type="submit" name="btnregistrar" value="Pagar" onClick="javascript: return confirm('¿Deseas cobrar a este veiculo?');">
                </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>
<?php

if (isset($_POST['btnregistrar'])) {

	$queryadd	= mysqli_query($conn, "UPDATE parking SET salida = '$salida', costo = '$costo' WHERE id = '$id'");

	if (!$queryadd) {
		echo "<script>alert('¡Error!, intenta otra vez');</script>";
	} else {
		echo "<script>window.location='../parking_tabla.php?pag=1' </script>";
	}
}
?>