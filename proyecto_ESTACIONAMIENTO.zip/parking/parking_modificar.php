<?php
include('../conexion.php');
include("../parking_tabla.php");

$pagina = $_GET['pag'];
$id = $_GET['id'];

$querybuscar = mysqli_query($conn, "SELECT * FROM parking WHERE id = '$id'");

while ($fila = mysqli_fetch_array($querybuscar)) :?>
    <html>
        <link rel="stylesheet" href="../css/style.css">
    <body>
        <div class="caja_popup2">
            <form class="contenedor_popup" method="POST" enctype="multipart/form-data">
                <table>
                    <tr>
                        <th colspan="2">Modificar vehiculo</th>
                    </tr>
                    <tr>
                        <td>Nombre del dueño</td>
                        <td><input class="CajaTexto" type="text" name="txtnombre" value="<?php echo $fila['nombre'] ?>" required></td>
                    </tr>
                    <tr>
                        <td>Tipo</td>
                        <td>
                            <select id="tipo" name="tipo">
                                <option value="">Selecciona un vehiculo</option>
                                <option value="moto">Moto $10/hora</option>
                                <option value="carro">Carro $15/hora</option>
                                <option value="camioneta">Camioneta $20/hora</option>
                                <option value="camion">Camión $25/hora</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Placas</td>
                        <td><input class="CajaTexto" type="text" name="placas" value="<?php echo $fila['placas'] ?>" required></td>
                    </tr>
                    <tr>
                        <td>Modelo</td>
                        <td><input class="CajaTexto" type="text" name="modelo" value="<?php echo $fila['modelo']; ?>" required></td>
                    </tr>
                    <tr>
                    <td colspan="2">
						<?php echo "<a class='BotonesTeam' href=\"../parking_tabla.php?pag=$pagina\">Cancelar</a>"; ?>&nbsp;
						<input class='BotonesTeam' type="submit" name="btnmodificar" value="Modificar" onClick="javascript: return confirm('¿Deseas modificar a este vehiculo?');">
					</td>
                    </tr>
                </table>
            </form>
        </div>
    </body>

    </html>

<?php
endwhile;

if (isset($_POST['btnmodificar'])) {
    $nombre     = $_POST['txtnombre'];
    $tipo = $_POST['tipo'];
    $placas = $_POST['placas'];
    $modelo = $_POST['modelo'];

    $querymodificar = mysqli_query($conn, "UPDATE parking SET nombre = '$nombre', tipo = '$tipo', placas = '$placas', `modelo` = '$modelo' WHERE id = '$id'");
    echo "<script>window.location='../parking_tabla.php?pag=" . $pagina . "' </script>";
}
?>