<?php
session_start();
include('conexion.php');
if (isset($_SESSION['usuario'])) {
	$usuarioingresado = $_SESSION['usuario'];
	$buscandousu = mysqli_query($conn, "SELECT * FROM usuarios WHERE correo = '" . $usuarioingresado . "'");
	$mostrar = mysqli_fetch_array($buscandousu);
} else {
	header('location: index.php');
}

if (isset($_GET['pag'])) {
	$pagina = $_GET['pag'];
} else {
	$pagina = 1;
}
date_default_timezone_set('America/Mexico_City');
?>

<html>

<head>
	<title>MENÚ</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/style.css">
</head>

<body>
	<div class="BarraLateral"><br>
		<form method="POST">
			<div class="ContBuscar">
				<div>
					<a href="parking_tabla.php" class="BotonesTeam">Inicio</a>
					<input class="BotonesTeam" type="submit" value="Buscar" name="btnbuscar">
					<input class="CajaTextoBuscar" type="text" name="txtbuscar" placeholder="Ingresar cliente" autocomplete="off">
				</div>
				<div>
					<?php echo "<a class='BotonesTeam5' href=\"./parking/parking_registrar.php?pag=$pagina\">Agregar vehiculo</a>"; ?>
				</div>
				<ul>
					<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>
				</ul>
			</div>
		</form>
	</div>
</body>

</html>