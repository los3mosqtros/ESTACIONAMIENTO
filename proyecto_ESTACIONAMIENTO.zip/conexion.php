<?php
$host 	= 'localhost';
$nom 	= 'id22306551_edlou';
$pass 	= 'Proyecto123:)';
$db 	= 'id22306551_proyecto';

$conn = mysqli_connect($host, $nom, $pass, $db);

if (!$conn) 
{
  die("Error en la conexión: " . mysqli_connect_error());
}

?>